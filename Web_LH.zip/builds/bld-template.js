build = {
    name: 'bld-0',
    title: 'Build #0 - Codename: ',
    systemtype: 'AMD',
    mb: {
        Product: "",
        html: "motherboard",
        amount: ""
    },
    cpu: {
        Product: "",
        html: "processor",
        amount: ""
    },
    cooling: {
        Product: "",
        html: "cooling",
        amount: ""
    },
    gpu: {
        Product: "",
        html: "graphics",
        amount: ""
    },
    mem: {
        Product: "",
        html: "memory",
        amount: ""
    },
    psu: {
        Product: "",
        html: "power",
        amount: ""
    },
    case: {
        Product: "",
        html: "case",
        amount: ""
    },
    drive1: {
        Product: "",
        html: "drive1",
        amount: ""
    },
    drive2: {
        Product: "",
        html: "drive2",
        amount: ""
    },
    drive3: {
        Product: "",
        html: "drive3",
        amount: ""
    },
    drive4: {
        Product: "",
        html: "drive4",
        amount: ""
    },
    optical: {
        Product: "",
        html: "optical",
        amount: ""
    },
    accessories: {
        Product: "",
        html: "",
        amount: ""
    },
    fans: {
        Product: "",
        html: "fans",
        amount: ""
    } 
};
module.exports = build;